-========================================================-
 Instructions for PoweredTemplates.com Word Templates
-========================================================-


We hope you make many great document files using our Word Templates.

Please read the recomendations below to make your work with our Word templates easier.


A. Formatting Text
-----------------------------------------------

What you see in the pre-set text boxes is a sample text. To edit it click Ctrl+A, then Del key. This is to select all text and then delete it. Now you can type in your own text.


B. Formatting Text Boxes
-----------------------------------------------

You can change the size of the pre-set text boxes you see in the document or create new ones.

To create a new text box go to Isert - Text Box in the Word menu, then click on the page and set the text box of the size you want.

Text box is white by default. Click on the side of it with the right mouse click and pick Format Text Box. In a new pop-up window set No Fill for Fill and No Line for Line parameters. Text box will become transparent.


C. Formatting Images
-----------------------------------------------

Click on the image and you'll see highlighting dots on its corners. You can delete the image or inlarge and make it smaller, also move it on the page.

To copy the image to the new page click on it, then click Ctrl+C, go to another page and click ctrl+V. Then adjust image on the page.

To insert your own image go to Insert - Picture - From File, browse for image and click OK.


D. Creating New Page
-----------------------------------------------

Adding a page in Word template is different from the usual Word document, because pages have text boxes and inserted images. Follow the instructions below.

To add new page:

1. Put cursor aside formatting boxes at the top of the last page.
2. Click Ctrl+Enter to create new page or several.

To copy layout and images of the template page to the new one:

1. Put cursor at the top of the page you want to copy.
2. Click Shift and down arrow and go to the bottom of the page.
3. Click Ctrl+C to save the layout.
4. Go to the new blank page and click Ctrl+V.
5. Adjust the layout.


E. Queries
-----------

If you have any further questions regarding PoweredTemplates.com Word templates please send email to:

support@poweredtemplates.com


F. Suggestions
--------------

If you have any suggestions as to PoweredTemplates.com Word templates, email us at:

comments@poweredtemplates.com.


G. Choose New templates
------------------------------

For the recent Word templates please visit

http://www.poweredtemplates.com/word-templates/index.html


==============================
POWEREDTEMPLATES.COM
==============================


Thank you for your purchase ar www.poweredtemplates.com.

December 2009

Microsoft Word(R) is a registered trademark of Microsoft Corporation in the United States and/or other countries. This software product was made by the company "XTLabs, Inc." and is in no way affiliated, connected or associated with Microsoft Corporation.
